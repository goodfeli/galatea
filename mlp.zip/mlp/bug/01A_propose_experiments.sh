python ~/spearmint-lite/spearmint-lite.py --n=50 .
