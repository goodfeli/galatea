import os
print 'PYLEARN2_PROFILE' in os.environ
